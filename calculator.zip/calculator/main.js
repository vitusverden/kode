function calculateinput() {
    document.getElementById("output").textContent = eval(document.getElementById("input").value)
}