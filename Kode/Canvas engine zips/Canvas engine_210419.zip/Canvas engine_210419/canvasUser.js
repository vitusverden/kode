window.onload=function() {
    init("black");
};
