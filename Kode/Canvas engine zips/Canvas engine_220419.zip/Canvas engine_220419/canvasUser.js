window.onload=function() {
    init("black");
};
function update() {
    
}